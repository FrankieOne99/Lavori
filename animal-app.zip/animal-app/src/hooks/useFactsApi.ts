import { useState, useEffect } from "react";

import FactsApi from "../services/factsApi";
import type { Facts } from "../interfaces/Facts.model";

const useFactsApi = () => {
  const [facts, setFacts] = useState<Facts>();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    FactsApi()
      .then((data) => {
        setFacts(data);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);
  return { facts, isLoading };
};
export default useFactsApi;
