import { useState, useEffect } from "react";

import DogsApi from "../services/dogsApi";
import type { Dogs } from "../interfaces/Dogs.model";

const useDogsApi = (pag: number | undefined) => {
  const [dogs, setDogs] = useState<Dogs>();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    DogsApi(pag)
      .then((data) => {
        setDogs(data);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [pag]);
  return { dogs, isLoading };
};
export default useDogsApi;
