import { useState, useEffect } from "react";

import DogsIdApi from "../services/dogsIdApi";
import type { DogId } from "../interfaces/DogId.model";

const useDogsIdApi = (id: string | undefined) => {
  const [dog, setDog] = useState<DogId>();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    DogsIdApi(id)
      .then((data) => {
        setDog(data);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [id]);
  return { dog, isLoading };
};
export default useDogsIdApi;
