export type Links = {
  self: string;
  current?: string;
  next?: string;
  last?: string;
};
