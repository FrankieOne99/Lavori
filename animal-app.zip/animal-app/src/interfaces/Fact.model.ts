export type Fact = {
  id: string;
  type: string;
  attributes: {
    body: string;
  };
};
