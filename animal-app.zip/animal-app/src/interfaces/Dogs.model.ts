import type { Dog } from "./Dog.model";
import type { Links } from "./Links.model";
import type { Meta } from "./Meta.model";

export type Dogs = {
  data: Dog[];
  meta?: Meta;
  links: Links;
};
