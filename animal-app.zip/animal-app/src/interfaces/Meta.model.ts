export type Meta = {
  pagination: {
    current: number;
    next: number;
    last: number;
    records: number;
  };
};
