import type { Fact } from "./Fact.model";

export type Facts = {
  data: Fact[];
};
