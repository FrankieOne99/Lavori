export const API_URL = "https://dogapi.dog/api/v2/breeds";

export const API_FACTS = "https://dogapi.dog/api/v2";
