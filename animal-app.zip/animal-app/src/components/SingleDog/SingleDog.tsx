import type { DogId } from "../../interfaces/DogId.model";
const SingleDog = (dog: DogId) => {
  return (
    <div className="dog-card">
      <h3>{dog?.data?.attributes?.name}</h3>
      <p>ID: {dog?.data?.id}</p>
      <p>Description: {dog?.data?.attributes?.description}</p>
    </div>
  );
};

export default SingleDog;
