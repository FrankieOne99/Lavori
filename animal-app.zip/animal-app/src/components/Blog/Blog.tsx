import { useState } from "react";
import useDogsIdApi from "../../hooks/useDogsIdApi";
import SingleDog from "../SingleDog/SingleDog";
function Blog() {
  // const { dog } = useDogsIdApi("dd9362cc-52e0-462d-b856-fccdcf24b140");

  const [value, setValue] = useState("");
  const [id, setId] = useState<string | undefined>("");

  const handleChange = (e) => {
    setValue(e.target.value);
  };
  const handleSubmit = () => {
    setId(value);
  };
  const { dog, isLoading } = useDogsIdApi(id);

  return (
    <div>
      <h1>Blog</h1>
      <input type="text" onChange={handleChange} />
      <button className="button" onClick={handleSubmit}>
        Invia
      </button>

      {!id || isLoading ? (
        <></>
      ) : (
        <div className="container">
          <SingleDog data={dog!.data} links={dog!.links}></SingleDog>
        </div>
      )}
    </div>
  );
}
export default Blog;
