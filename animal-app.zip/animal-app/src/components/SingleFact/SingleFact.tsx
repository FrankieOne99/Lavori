// import type { Fact } from "../../interfaces/Fact.model";

import type { Fact } from "../../interfaces/Fact.model";

function SingleFact(fact: Fact) {
  return <div className="container">{fact.attributes.body}</div>;
}
export default SingleFact;
