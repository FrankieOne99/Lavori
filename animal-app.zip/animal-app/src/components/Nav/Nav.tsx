import { Link } from "react-router";

function Nav() {
  return (
    <>
      <nav>
        <li>
          <Link className="link" to={"/"}>
            Home
          </Link>
        </li>
        <li>
          <Link className="link" to={"/Blog"}>
            Blog
          </Link>
        </li>
        <li>
          <Link className="link" to={"/Facts"}>
            Facts
          </Link>
        </li>
      </nav>
    </>
  );
}
export default Nav;
