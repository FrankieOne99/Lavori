import type { Dog } from "../../interfaces/Dog.model";
function DogList(dog: Dog) {
  return (
    <div className="dog-card">
      <h3>{dog.attributes.name}</h3>
      <p>ID: {dog.id}</p>
      <p>Description: {dog.attributes.description}</p>
    </div>
  );
}
export default DogList;
