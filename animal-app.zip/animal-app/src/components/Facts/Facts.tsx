// import type { Fact } from "../../interfaces/Fact.model";

import useFactsApi from "../../hooks/useFactsApi";
import SingleFact from "../SingleFact/SingleFact";

function Facts() {
  const { facts, isLoading } = useFactsApi();
  return (
    <>
      {isLoading ? (
        <p>loading...</p>
      ) : (
        facts?.data.map((f, index) => (
          <SingleFact
            key={index}
            id={f.id}
            type={f.type}
            attributes={f.attributes}
          ></SingleFact>
        ))
      )}
    </>
  );
}
export default Facts;

// import type { Fact } from "../../interfaces/Fact.model";
