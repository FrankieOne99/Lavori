import { useState } from "react";
import useDogsApi from "../../hooks/useDogsApi";
import DogList from "../DogList/DogList";

function Home() {
  const [pag, setPag] = useState(1);
  // const [id, setId] = useState("036feed0-da8a-42c9-ab9a-57449b530b13");

  function nextPage() {
    if (pag < 29) {
      setPag(pag + 1);
    }
  }
  function previousPage() {
    if (pag > 1) {
      setPag(pag - 1);
    }
  }

  const { dogs, isLoading } = useDogsApi(pag);

  return (
    <>
      <h1>Dogs Api</h1>

      <button className="button" onClick={previousPage}>
        Pagina precedente
      </button>
      <button className="button" onClick={nextPage}>
        Pagina successiva
      </button>
      {isLoading ? (
        <p>loading...</p>
      ) : (
        <div className="container">
          {dogs?.data.map((dog, index) => (
            <DogList
              key={index}
              id={dog.id}
              attributes={dog.attributes}
              type={dog.type}
            ></DogList>
          ))}
        </div>
      )}
    </>
  );
}

export default Home;
