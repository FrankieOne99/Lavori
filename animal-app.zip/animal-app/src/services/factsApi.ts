import { API_FACTS } from "../costants";

const FactsApi = async () => {
  const res = await fetch(`${API_FACTS}/facts`);

  if (!res.ok) {
    throw new Error(`Fetch error ${res.status}: resource not found`);
  } else {
    const data = await res.json();
    return data;
  }
};

export default FactsApi;
