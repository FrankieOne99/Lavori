import { API_URL } from "../costants";

const DogsIdApi = async (id: string | undefined) => {
  let res;
  if (!id) {
    res = await fetch(`${API_URL}`);
  } else {
    res = await fetch(`${API_URL}/${id}`);
  }
  if (!res.ok) {
    throw new Error(`Fetch error ${res.status}: resource not found`);
  } else {
    const data = await res.json();
    return data;
  }
};
export default DogsIdApi;
