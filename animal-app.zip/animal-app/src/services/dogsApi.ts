import { API_URL } from "../costants";

const DogsApi = async (pag: number | undefined) => {
  let res;

  if (!pag) {
    res = await fetch(API_URL);
  } else {
    res = await fetch(`${API_URL}/${"?page[number]="}${pag}`);
  }

  if (!res.ok) {
    throw new Error(`Fetch error ${res.status}: resource not found`);
  } else {
    const data = await res.json();
    return data;
  }
};

export default DogsApi;
