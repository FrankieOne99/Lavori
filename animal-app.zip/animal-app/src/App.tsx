import { BrowserRouter, Route, Routes } from "react-router";
import "./App.css";
import Home from "./components/Home/Home";
import Nav from "./components/Nav/Nav";
import Blog from "./components/Blog/Blog";
import Facts from "./components/Facts/Facts";

function App() {
  return (
    <>
      <BrowserRouter>
        <Nav />
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/Blog" element={<Blog />}></Route>
          <Route path="/Facts" element={<Facts />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
